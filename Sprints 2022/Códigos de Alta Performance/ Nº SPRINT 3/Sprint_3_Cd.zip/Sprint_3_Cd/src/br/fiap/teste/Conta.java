package br.fiap.teste;

public enum Conta {
	FISICA, JURIDICA	
}
