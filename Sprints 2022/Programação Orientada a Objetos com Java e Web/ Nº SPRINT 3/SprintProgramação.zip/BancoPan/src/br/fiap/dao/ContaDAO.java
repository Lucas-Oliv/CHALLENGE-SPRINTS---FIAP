package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Conta;
import static java.lang.Double.parseDouble;

public class ContaDAO {
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	public void inserir(Conta conta) {
		connection = new Conexao().conectar();
		sql = "insert into t_sbp_conta(nr_conta, dt_abertura, vl_saldo) values (?,?,?) ";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1,conta.getNrConta());
			ps.setString(2,conta.getDtAbertura());
			ps.setDouble(3,conta.getSaldo());
			ps.execute();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("Erro ao inserir conta" + e);
		}
	}
	
	public Conta pesquisar(int nrConta) {
		Conta c = null;
		connection = new Conexao().conectar();
		sql = "select * from t_sbp_conta where nr_conta = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nrConta);
			rs = ps.executeQuery();
			if(rs.next()) {
				c = new Conta(rs.getInt("nr_conta"),rs.getString("dt_abertura") ,rs.getDouble("vl_saldo") );
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("erro pesquisa conta" + e);
		}
		return c;
	}
	
}
