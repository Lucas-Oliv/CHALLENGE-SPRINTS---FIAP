package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Contato;

public class ContatoDAO {

	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	public void inserir(Contato contato) {
		connection = new Conexao().conectar();
		sql = "insert into t_sbp_contato(ds_email, cd_produto, nr_telefone, nr_celular) values (?,?,?,?) ";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, contato.getEmail());
			ps.setInt(2, contato.getCdProduto());
			ps.setInt(3, contato.getTelefone());
			ps.setInt(4, contato.getCelular());
			ps.execute();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("erro ao inseir contato" + e);
		}
	}
	
	
	public void atualizar(String email, int telefone) {
		connection = new Conexao().conectar();
		sql = "update t_sbp_contato set nr_telefone = ? where ds_email = ?";
		 try {
			 ps = connection.prepareStatement(sql);
			 ps.setInt(1, telefone);
			 ps.setString(2, email);
			 ps.execute();
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("erro ao atualizar telfone" +e);
		}
	}
	
	
	
	
	
}
