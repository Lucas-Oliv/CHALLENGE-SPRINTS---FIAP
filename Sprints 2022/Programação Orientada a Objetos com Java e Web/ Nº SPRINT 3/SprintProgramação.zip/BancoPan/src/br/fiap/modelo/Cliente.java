package br.fiap.modelo;

public class Cliente {
	int cdCliente;
	String dtNasc;
	String genero;
	String cpf;
	String cnpj;
	String rg;
	String nome;
	
	
	
	
	public Cliente(int cdCliente, String dtNasc, String genero, String cpf, String cnpj, String rg, String nome) {
		super();
		this.cdCliente = cdCliente;
		this.dtNasc = dtNasc;
		this.genero = genero;
		this.cpf = cpf;
		this.cnpj = cnpj;
		this.rg = rg;
		this.nome = nome;
	}
	public int getCdCliente() {
		return cdCliente;
	}
	public void setCdCliente(int cdCliente) {
		this.cdCliente = cdCliente;
	}
	public String getDtNasc() {
		return dtNasc;
	}
	public void setDtNasc(String dtNasc) {
		this.dtNasc = dtNasc;
	}
	public String getGenero() {
		return genero;
	}
	public void setGenero(String genero) {
		this.genero = genero;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
}
