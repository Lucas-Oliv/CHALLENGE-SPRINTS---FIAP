package br.fiap.main;

import java.util.Random;
import java.util.Scanner;

import br.fiap.dao.ClienteDAO;
import br.fiap.dao.ContaDAO;
import br.fiap.dao.ContatoDAO;
import br.fiap.modelo.Cliente;
import br.fiap.modelo.Conta;
import br.fiap.modelo.Contato;

public class principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner teclado = new Scanner(System.in);
		ClienteDAO dao = new ClienteDAO();
		ContaDAO c = new ContaDAO();
		ContatoDAO contato = new ContatoDAO();
		
		int cdCliente;
		String dtNasc;
		String genero;
		String cpf;
		String cnpj;
		String rg;
		String nome;
		int nrConta;
		String DtAbertura;
		double saldo = 0;
		String email;
		int cdProduto;
		int telefone;
		int celular;
		int op=0;
		
		// menu 
		
		
		
		do {
			
			System.out.println("1.Cadastra cliente\n" 
					+ "2.Pesquisar conta\n"
					+ "3.Atualizar contato\n"
					+ "4.Sair"
							);
					op= teclado.nextInt();
			switch(op) {
			case 1:
				//insere cliente no banco
				System.out.println("Insira o c�digo do cliente ");
				cdCliente = teclado.nextInt();
				System.out.println("Insira sua data de nascimento ");
				dtNasc = teclado.next();
				System.out.println("Insira seu genero ");
				genero = teclado.next();
				System.out.println("insira seu cpf");
				cpf = teclado.next();
				System.out.println("Insira sua cnpj");
				cnpj = teclado.next();
				System.out.println("Insria seu rg");
				rg = teclado.next();
				System.out.println("Insira seu nome ");
				nome= teclado.next();
				dao.inserir(new Cliente(cdCliente,dtNasc, genero,cpf,cnpj,rg,nome));
				
				System.out.println("Insira as informações de contato \n");
				
				//inserir contato 
				System.out.println("Insira seu email: ");
				email = teclado.next();
				System.out.println("insira o codigo do produto ou 0 caso não tenha");
				cdProduto = teclado.nextInt();
				System.out.println("Numero do telefone");
				telefone = teclado.nextInt();
				System.out.println("insira o numero do celular");
				celular = teclado.nextInt();
				contato.inserir(new Contato(email, cdProduto, telefone,celular));
				
				//gerar conta 
				System.out.println("Crie um numero para sua conta: ");
				nrConta = teclado.nextInt();
				System.out.println("insira o mes de abertura\n");
				DtAbertura = teclado.next();
			
				c.inserir(new Conta(nrConta,DtAbertura,saldo));
				
				break;
				
			case 2:
				System.out.println("Insira seu numero de conta:");
				nrConta= teclado.nextInt();
			    Conta conta = c.pesquisar(nrConta);
			    System.out.println(conta);
				
			    break;
			    
			case 3:
				System.out.println("\n Atualizar telefone de contato\n");
				System.out.println("Digite o seu email: ");
				email = teclado.next();
				System.out.println("digite seu novo numero de telefone:");
				telefone = teclado.nextInt();
			    contato.atualizar(email, telefone);
			    
				break;
			}
			
			
		} while (op!=4);
		
		
		
	// inserir informacoes para conatato 
		
		
		// inserir conta 
		
		
		// inserir Cliente 
		
		
		
		
		// pesquisar a conta atraves do nr da conta 
	
	    
		
		//atualizar telefone atraves do email 
		
		
		
	}



}
