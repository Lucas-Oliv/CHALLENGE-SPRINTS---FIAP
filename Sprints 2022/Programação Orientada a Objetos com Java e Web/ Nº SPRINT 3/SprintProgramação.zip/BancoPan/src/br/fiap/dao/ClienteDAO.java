package br.fiap.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Cliente;
public class ClienteDAO {
	
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;
	
	public void inserir(Cliente cliente) {
		connection = new Conexao().conectar();
		
		
		sql = "INSERT INTO T_SBP_CLIENTE(CD_CLIENTE, DT_NASCIMENTO, DS_GENERO,NR_CPF,NR_CNPJ,NR_RG,NM_CLIENTE) VALUES(?, ?, ?, ?, ?, ?, ?)";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, cliente.getCdCliente());
			ps.setString(2, cliente.getDtNasc());
			ps.setString(3, cliente.getGenero());
			ps.setString(4, cliente.getCpf());
			ps.setString(5, cliente.getCnpj());
			ps.setString(6, cliente.getRg());
			ps.setString(7, cliente.getNome());
			ps.execute();
			connection.close();
			
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println("erro ao inseirir" + e);
		}
	}
}
