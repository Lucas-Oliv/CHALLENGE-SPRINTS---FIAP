package br.fiap.modelo;

public class Contato {

	String email;
	int cdProduto;
	int telefone;
	int celular;
	
	
	
	
	public Contato(String email, int cdProduto, int telefone, int celular) {
		super();
		this.email = email;
		this.cdProduto = cdProduto;
		this.telefone = telefone;
		this.celular = celular;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCdProduto() {
		return cdProduto;
	}
	public void setCdProduto(int cdProduto) {
		this.cdProduto = cdProduto;
	}
	public int getTelefone() {
		return telefone;
	}
	public void setTelefone(int telefone) {
		this.telefone = telefone;
	}
	public int getCelular() {
		return celular;
	}
	public void setCelular(int celular) {
		this.celular = celular;
	}
	
	
	
}
