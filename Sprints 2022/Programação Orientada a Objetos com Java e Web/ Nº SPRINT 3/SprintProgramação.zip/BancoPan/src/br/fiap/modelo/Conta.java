package br.fiap.modelo;

import java.util.Random;

import br.fiap.dao.ContaDAO;

public class Conta {
int nrConta;
String DtAbertura;
static double saldo = 0;
public Conta(int nrConta, String dtAbertura, double saldo) {
	super();
	this.nrConta = nrConta;
	DtAbertura = dtAbertura;
	this.saldo = saldo;
}


public Conta(int nrConta) {
	super();
	this.nrConta = nrConta;
}


public int getNrConta() {
	return nrConta;
}
public void setNrConta(int nrConta) {
	this.nrConta = nrConta;
}
public String getDtAbertura() {
	return DtAbertura;
}
public void setDtAbertura(String dtAbertura) {
	DtAbertura = dtAbertura;
}
public double getSaldo() {
	return saldo;
}
public void setSaldo(double saldo) {
	this.saldo = saldo;
}


@Override
public String toString() {
	return "Conta [nrConta=" + nrConta + ", DtAbertura=" + DtAbertura + ", saldo=" + saldo + "]";
}








}
