package br.fiap.dao;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Cliente;

public class ClienteDAO extends DAO{

	//inserir
	public void inserir(Cliente cliente) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into t_sprint_cliente values(?,?,?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, cliente.getId_cliente());
			ps.setString(2, cliente.getNm_cliente());
			ps.setInt(3, cliente.getCpf());
			
			ps.execute();	
			ps.close();
			conexao.desconectar();
			
			
		} catch (Exception e) {
			System.out.println("erro ao inserir"+ e);
		}
		
	}
	
	//pesquisar
	public Cliente pesquisar(int cd_cliente) {
		Cliente cliente = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		sql = "select * from t_sprint_cliente where cd_cliente = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, cd_cliente);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				cliente = new Cliente();
				cliente.setId_cliente(rs.getInt("id_cliente"));
				cliente.setNm_cliente(rs.getString("nm_cliente"));
				cliente.setCpf(rs.getInt("nr_cpf"));
			}
			ps.close();
			conexao.desconectar();
			
			
		} catch (Exception e) {
			System.out.println("erro ao pesquisar" + e);
		}
		return cliente;
		
	}
	
}
