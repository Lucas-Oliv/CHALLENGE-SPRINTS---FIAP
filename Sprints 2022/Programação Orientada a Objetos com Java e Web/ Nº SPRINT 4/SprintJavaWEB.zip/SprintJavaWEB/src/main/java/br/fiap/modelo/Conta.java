package br.fiap.modelo;

public class Conta {
	
	private Integer nr_conta;
	private String nr_cpf;
	private String senha;
	
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	
	public Integer getNr_conta() {
		return nr_conta;
	}
	public void setNr_conta(Integer nr_conta) {
		this.nr_conta = nr_conta;
	}
	public String getNr_cpf() {
		return nr_cpf;
	}
	public void setNr_cpf(String nr_cpf) {
		this.nr_cpf = nr_cpf;
	}
	
	
}
