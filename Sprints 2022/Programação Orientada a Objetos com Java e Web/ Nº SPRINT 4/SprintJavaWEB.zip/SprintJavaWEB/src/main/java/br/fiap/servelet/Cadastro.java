package br.fiap.servelet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.ClienteDAO;
import br.fiap.dao.ContaDAO;
import br.fiap.modelo.Cliente;
import br.fiap.modelo.Conta;

/**
 * Servlet implementation class Cadastro
 */
@WebServlet("/Cadastro")
public class Cadastro extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Cadastro() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cliente cliente = new Cliente();
		ClienteDAO dao = new ClienteDAO(); 
		
		cliente.setId_cliente(Integer.parseInt(request.getParameter("id_cliente")));
		cliente.setNm_cliente(request.getParameter("nm_cliente"));
		cliente.setCpf(Integer.parseInt(request.getParameter("nr_cpf")));
		
		dao.inserir(cliente);
		
		Conta conta = new Conta();
		ContaDAO contadao = new ContaDAO();
		
		conta.setNr_conta(Integer.parseInt(request.getParameter("nr_conta")));
		conta.setNr_cpf(request.getParameter("nr_cpf"));
		conta.setSenha(request.getParameter("senha"));
		
		contadao.inserir(conta);
		
		
		
		// redireciona para index.jsp
				RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
				dispatcher.forward(request, response);
	}

}
