package br.fiap.dao;

import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.Contato;
import br.fiap.modelo.Cliente;
import br.fiap.modelo.Conta;

public class ContaDAO extends DAO {

	
	public void inserir(Conta conta) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		sql = "insert into t_sprint_conta values(?,?,?)";
		
		
		try {
			
			ps = connection.prepareStatement(sql);
			ps.setInt(1, conta.getNr_conta());
			ps.setString(2, conta.getNr_cpf());
			ps.setString(3, conta.getSenha());
			
			ps.execute();	
			ps.close();
			conexao.desconectar();
			
		} catch (Exception e) {
			System.out.println("erro ao inserir uma conta" + e);
		}
	}
	
	
	public Conta pesquisar(int nr_conta, String senha) {
		Conta conta = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		sql = "select * from t_sprint_conta where nr_conta = ? and senha = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nr_conta);
			ps.setString(2, senha);
			rs = ps.executeQuery();
			
			if (rs.next()) {
				conta = new Conta();
				conta.setNr_conta(rs.getInt("nr_conta"));
				conta.setNr_cpf(rs.getNString("nr_cpf"));
				conta.setSenha(rs.getString("senha"));
			}
			ps.close();
			conexao.desconectar();
			
			
		} catch (Exception e) {
			System.out.println("erro ao pesquisar conta" + e);
		}
		return conta;
		
	}
	
	public Conta pesquisarN(int nr_conta) {
		Conta conta = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		
		sql = "select * from t_sprint_conta where nr_conta = ?";
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, nr_conta);
			
			rs = ps.executeQuery();
			
			if (rs.next()) {
				conta = new Conta();
				conta.setNr_conta(rs.getInt("nr_conta"));
				conta.setNr_cpf(rs.getNString("nr_cpf"));
				conta.setSenha(rs.getString("senha"));
			}
			ps.close();
			conexao.desconectar();
			
			
		} catch (Exception e) {
			System.out.println("erro ao pesquisar conta" + e);
		}
		return conta;
		
	}
	
	public List<Conta> listar() {
		List<Conta> lista = new ArrayList<Conta>();
		Conta conta;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from t_sprint_conta";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				conta = new Conta();
				conta.setNr_conta(rs.getInt("nr_conta"));
				conta.setNr_cpf(rs.getNString("nr_cpf"));
				conta.setSenha(rs.getString("senha"));
				lista.add(conta);
			}			
			ps.close();
			conexao.desconectar();
		}
		catch(SQLException e) {
			System.out.println("Erro ao listar na base de dados\n" + e);
		}
		
		return lista;
	}
	
	public void alterar(Conta conta) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "update t_sprint_conta set nr_cpf = ?, senha = ? where nr_conta = ?";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, conta.getNr_cpf());
			ps.setString(2, conta.getSenha());
			ps.setInt(3, conta.getNr_conta());
			
			ps.execute();		
			ps.close();
			conexao.desconectar();
		}
		catch(SQLException e) {
			System.out.println("Erro ao alterar dados do contato na base de dados\n" + e);
		}		
	}
	
}
