package br.fiap.modelo;

public class Contato {
	private Integer cd_cliente;
	private String ds_email;
	private String ds_endereco;
	
	
	public Integer getCd_cliente() {
		return cd_cliente;
	}
	public void setCd_cliente(Integer cd_cliente) {
		this.cd_cliente = cd_cliente;
	}
	public String getDs_email() {
		return ds_email;
	}
	public void setDs_email(String ds_email) {
		this.ds_email = ds_email;
	}
	public String getDs_endereco() {
		return ds_endereco;
	}
	public void setDs_endereco(String ds_endereco) {
		this.ds_endereco = ds_endereco;
	}
	
	
}
