package br.fiap.modelo;

public class Cliente {
	private Integer id_cliente;
	private String nm_cliente;
	private Integer nr_cpf;
	
	
	public Integer getId_cliente() {
		return id_cliente;
	}
	public void setId_cliente(Integer id_cliente) {
		this.id_cliente = id_cliente;
	}
	public String getNm_cliente() {
		return nm_cliente;
	}
	public void setNm_cliente(String nm_cliente) {
		this.nm_cliente = nm_cliente;
	}
	public Integer getCpf() {
		return nr_cpf;
	}
	public void setCpf(Integer cpf) {
		this.nr_cpf = cpf;
	}
	
	
	
	
	
}
