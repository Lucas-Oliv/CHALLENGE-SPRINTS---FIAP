package br.bancopan;

import br.bancopan.produto.Produto;

public abstract class Pessoa extends Produto{

	protected String nome;
	protected String cpf;
	protected String rg;
	protected String sexo;
	
	



	public Pessoa(int codproduto, String refproduto, String nome, String cpf, String rg, String sexo) {
		super(codproduto, refproduto);
		this.nome = nome;
		this.cpf = cpf;
		this.rg = rg;
		this.sexo = sexo;
	}




	@Override
	public String toString() {
		String aux = "";
		aux += "Nome: " + getNome() + "\n";
		aux += "Cpf: " + getCpf() + "\n";
		aux += "Rg: " + getRg() + "\n";
		aux += "Sexo: " + getSexo()+ "\n";
		return aux;
	}




	public String getNome() {
		return nome;
	}




	public void setNome(String nome) {
		this.nome = nome;
	}




	public String getCpf() {
		return cpf;
	}




	public void setCpf(String cpf) {
		this.cpf = cpf;
	}




	public String getRg() {
		return rg;
	}




	public void setRg(String rg) {
		this.rg = rg;
	}




	public String getSexo() {
		return sexo;
	}




	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	
	
	
	
}
