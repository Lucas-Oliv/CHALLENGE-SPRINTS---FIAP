package br.bancopan.controle;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.util.ArrayList;

import br.bancopan.Cliente;
import br.bancopan.Funcionario;
import br.bancopan.Pessoa;

public class Controle {

	private ArrayList<Pessoa> lista = new ArrayList<Pessoa>();

	public void menu() {
		String aux = "Escolha uma op��o\n1. Lista \n2. Finalizar";
		int opcao = 0;

		do {

			try {
				opcao = parseInt(showInputDialog(aux));

				if (opcao < 1 || opcao > 2) {
					showMessageDialog(null, "Op��o Errada", "Erro", 0);
				} else if (opcao == 1) {
					listaGeral();
					remover();
					}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "Deve digitar um n�mero", "Erro", 0);
			}

		} while (opcao != 2);

	}

	private void listaGeral() {
		String funcio = "Funcionario\n";
		String cliente = "Cliente\n";
		lista.add(new Funcionario(12, "cartao", "Carlos", "1234", "1243", "1235", 12234, 12000));
		lista.add(new Funcionario(12, "cartao", "Lucas", "11234", "1534243", "112235", 1222334, 18000));
		lista.add(new Cliente(12, "Carro", "Jose", "1234", "12345", "home", "tal@tal", "Av. tal", "23/12/4312", 11111,
				123));
		lista.add(new Cliente(12, "Carro", "Antonio", "1234", "12345", "home", "tal@tal", "Av. tal", "23/12/4312",
				11111, 123));
		for (Pessoa f : lista) {
			if (f instanceof Funcionario) {
				funcio += f + "\n";
			} else if (f instanceof Cliente) {
				cliente += f + "\n";
			}
		}
		showMessageDialog(null, "\n" + funcio + "\n" + "\n" + cliente);
	}

	private void remover() {
		int indice =  -1;
		if(indice != -1) {
			lista.remove(indice);
		}
	}
	
}
