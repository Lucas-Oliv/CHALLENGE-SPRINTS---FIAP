package br.bancopan.produto;



public class Produto {
	
	
   protected int codproduto;
   protected String refproduto;
   
   
public Produto(int codproduto, String refproduto) {
	super();
	this.codproduto = codproduto;
	this.refproduto = refproduto;
}


@Override
public String toString() {
	String aux = "";
	aux += "Codigo do Produto: " + codproduto;
	aux+= "Referencia: "+ refproduto;
	return aux;
}
   
   
  
}
