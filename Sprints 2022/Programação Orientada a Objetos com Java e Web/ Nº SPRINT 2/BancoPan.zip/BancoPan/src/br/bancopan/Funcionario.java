package br.bancopan;

public class Funcionario extends Pessoa{

	protected int codigodoFuncionario;
	protected double salario;
	


	public Funcionario(int codproduto, String refproduto, String nome, String cpf, String rg, String sexo,
			int codigodoFuncionario, double salario) {
		super(codproduto, refproduto, nome, cpf, rg, sexo);
		this.codigodoFuncionario = codigodoFuncionario;
		this.salario = salario;
	}



	@Override
	public String toString() {
		String aux = super.toString();
		aux += "Codigo do Funcionario: " + codigodoFuncionario+"\n";
		aux += "Salario R$"+ salario;
		return aux;
	}
	
	
	
	
}
