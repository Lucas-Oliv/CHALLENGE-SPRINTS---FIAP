package br.bancopan.Main;


import br.bancopan.controle.Controle;


public class Main {
	public static void main(String[] args) {

		Controle controle = new Controle();
		controle.menu();
		
	}

}
