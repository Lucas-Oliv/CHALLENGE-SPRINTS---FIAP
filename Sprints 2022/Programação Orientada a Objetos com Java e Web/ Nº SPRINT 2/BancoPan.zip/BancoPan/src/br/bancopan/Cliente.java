package br.bancopan;

public class Cliente extends Pessoa{

	protected String email, endereco, datanacimento;
	protected int celular, codigodoCliente;
	
	
	

	public Cliente(int codproduto, String refproduto, String nome, String cpf, String rg, String sexo, String email,
			String endereco, String datanacimento, int celular, int codigodoCliente) {
		super(codproduto, refproduto, nome, cpf, rg, sexo);
		this.email = email;
		this.endereco = endereco;
		this.datanacimento = datanacimento;
		this.celular = celular;
		this.codigodoCliente = codigodoCliente;
	}




	@Override
	public String toString() {
		String aux = super.toString();
		aux += "Email: " + email + "\n";
		aux += "Endereco: " + endereco + "\n";
		aux += "Data de Nacimento: " + datanacimento + "\n";
		aux += "Celular: " + celular+ "\n";
		aux += "Codigo do Cliente: " + codigodoCliente+ "\n";
		aux += "Produto " + refproduto+"\n";
		aux += "COdigo do Produto: " + codproduto+"\n";
		return aux;
	}
	
	
	
}
